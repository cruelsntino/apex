#! /bin/bash

echo "Hello wibe!"